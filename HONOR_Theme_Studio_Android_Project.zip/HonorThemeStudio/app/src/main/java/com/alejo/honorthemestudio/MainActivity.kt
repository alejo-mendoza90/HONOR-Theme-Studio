package com.alejo.honorthemestudio

import android.app.WallpaperManager
import android.content.Intent
import android.graphics.Bitmap
import android.graphics.Canvas
import android.graphics.Paint
import android.graphics.RectF
import android.net.Uri
import android.os.Bundle
import android.provider.Settings
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.appcompat.app.AppCompatActivity
import android.content.Context
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable

class MainActivity : AppCompatActivity() {
    private val prefs by lazy { getSharedPreferences("theme_studio", Context.MODE_PRIVATE) }
    private var accent = Color.rgb(0, 210, 190)
    private var background = Color.rgb(10, 13, 20)
    private lateinit var root: LinearLayout
    private lateinit var preview: LinearLayout
    private lateinit var status: TextView

    private val imagePicker = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let { applyWallpaper(it) }
    }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        accent = prefs.getInt("accent", accent)
        buildScreen()
    }

    private fun buildScreen() {
        val scroll = ScrollView(this).apply { setBackgroundColor(background) }
        root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(dp(20), dp(26), dp(20), dp(28))
        }
        scroll.addView(root)
        setContentView(scroll)

        addText("HONOR THEME STUDIO", 23f, Color.WHITE, true)
        addText("Personaliza tu Magic6 Lite", 14f, 0xFF9AA6B7.toInt(), false)
        addSpace(18)

        preview = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            gravity = Gravity.CENTER
            setPadding(dp(16), dp(22), dp(16), dp(22))
            background = rounded(0xFF171F2B.toInt(), 24)
        }
        val previewTitle = TextView(this).apply {
            text = "VISTA PREVIA · ESTILO OSCURO"
            textSize = 11f
            setTextColor(0xFF9AA6B7.toInt())
            letterSpacing = .08f
        }
        preview.addView(previewTitle)
        val clock = TextView(this).apply {
            text = "09:41"
            textSize = 48f
            typeface = Typeface.create("sans-serif-light", Typeface.NORMAL)
            setTextColor(Color.WHITE)
            gravity = Gravity.CENTER
        }
        preview.addView(clock)
        val date = TextView(this).apply {
            text = "Martes · Tu pantalla, tu estilo"
            textSize = 13f
            setTextColor(0xFFB7C2D0.toInt())
        }
        preview.addView(date)
        val chipRow = LinearLayout(this).apply {
            gravity = Gravity.CENTER
            setPadding(0, dp(18), 0, 0)
        }
        listOf("Teléfono", "Cámara", "Mensajes", "Música").forEachIndexed { index, name ->
            val chip = TextView(this).apply {
                text = listOf("☎", "◉", "✉", "♫")[index] + "\\n" + name
                gravity = Gravity.CENTER
                textSize = 11f
                setTextColor(Color.WHITE)
                setPadding(dp(9), dp(9), dp(9), dp(9))
                background = rounded(accent, 14)
            }
            val lp = LinearLayout.LayoutParams(0, dp(70), 1f)
            lp.setMargins(dp(3), 0, dp(3), 0)
            chipRow.addView(chip, lp)
        }
        preview.addView(chipRow)
        root.addView(preview, LinearLayout.LayoutParams(-1, -2))
        addSpace(22)

        section("FONDOS DE PANTALLA")
        addButton("Elegir una imagen y aplicarla como fondo") { imagePicker.launch("image/*") }
        addButton("Crear fondo degradado HONOR") { applyGeneratedWallpaper() }

        section("COLORES DEL TEMA")
        addText("Selecciona un color de acento para la vista previa y los fondos generados.", 13f, 0xFF9AA6B7.toInt(), false)
        val colors = listOf(
            "Turquesa" to Color.rgb(0, 210, 190),
            "Azul eléctrico" to Color.rgb(55, 130, 255),
            "Violeta" to Color.rgb(165, 100, 255),
            "Rojo" to Color.rgb(255, 75, 95),
            "Dorado" to Color.rgb(230, 180, 75)
        )
        colors.forEach { (name, color) ->
            addButton("●  $name") {
                accent = color
                prefs.edit().putInt("accent", color).apply()
                buildScreen()
            }
        }

        section("HERRAMIENTAS DEL TELÉFONO")
        addButton("Abrir ajustes de pantalla") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        addButton("Abrir ajustes de modo oscuro") { openSettings(Settings.ACTION_DISPLAY_SETTINGS) }
        addButton("Abrir ajustes de sonido") { openSettings(Settings.ACTION_SOUND_SETTINGS) }
        addButton("Abrir ajustes de pantalla de bloqueo") { openSettings(Settings.ACTION_SECURITY_SETTINGS) }

        section("QUÉ PUEDE PERSONALIZAR")
        addText(
            "✓ Aplicar fondos de pantalla\\n✓ Crear fondos degradados\\n✓ Guardar un color de acento\\n✓ Previsualizar una combinación visual\\n✓ Abrir los ajustes nativos de Android",
            14f, 0xFFD4DCE7.toInt(), false
        )
        addSpace(12)
        addText(
            "LÍMITES DE ANDROID / MAGICOS\\nUna app normal no puede reemplazar por sí sola los iconos del sistema, la pantalla de bloqueo HONOR, la barra de estado, el panel rápido, fuentes del sistema ni todos los recursos de MagicOS. Para esos cambios se necesita compatibilidad con HONOR Themes, permisos del sistema o herramientas específicas. Esta app no usa root ni modifica archivos protegidos.",
            12f, 0xFF8995A6.toInt(), false
        )
        addSpace(12)
        status = TextView(this).apply {
            text = "HONOR Theme Studio · versión 1.0"
            textSize = 11f
            setTextColor(0xFF667386.toInt())
            gravity = Gravity.CENTER
        }
        root.addView(status, LinearLayout.LayoutParams(-1, -2))
    }

    private fun applyWallpaper(uri: Uri) {
        try {
            val bitmap = contentResolver.openInputStream(uri)?.use { android.graphics.BitmapFactory.decodeStream(it) }
                ?: throw IllegalStateException("No se pudo leer la imagen")
            WallpaperManager.getInstance(this).setBitmap(bitmap)
            toast("Fondo aplicado correctamente")
        } catch (e: Exception) {
            toast("No se pudo aplicar el fondo: ${e.localizedMessage}")
        }
    }

    private fun applyGeneratedWallpaper() {
        try {
            val w = 1080
            val h = 2400
            val bitmap = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
            val canvas = Canvas(bitmap)
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            paint.shader = android.graphics.LinearGradient(
                0f, 0f, w.toFloat(), h.toFloat(),
                intArrayOf(0xFF080D18.toInt(), accent, 0xFF080D18.toInt()),
                null, android.graphics.Shader.TileMode.CLAMP
            )
            canvas.drawRect(0f, 0f, w.toFloat(), h.toFloat(), paint)
            paint.shader = null
            paint.color = 0x22FFFFFF
            canvas.drawCircle(850f, 520f, 420f, paint)
            paint.color = 0x18000000
            canvas.drawRoundRect(RectF(80f, 1450f, 1000f, 2050f), 70f, 70f, paint)
            WallpaperManager.getInstance(this).setBitmap(bitmap)
            toast("Fondo HONOR generado y aplicado")
        } catch (e: Exception) {
            toast("No se pudo generar el fondo: ${e.localizedMessage}")
        }
    }

    private fun openSettings(action: String) {
        try { startActivity(Intent(action)) }
        catch (_: Exception) { toast("Este acceso no está disponible en esta versión de Android") }
    }

    private fun section(title: String) {
        addSpace(20)
        addText(title, 13f, accent, true)
        addSpace(7)
    }

    private fun addText(value: String, size: Float, color: Int, bold: Boolean) {
        root.addView(TextView(this).apply {
            text = value
            textSize = size
            setTextColor(color)
            if (bold) typeface = Typeface.create("sans-serif", Typeface.BOLD)
            setLineSpacing(dp(3).toFloat(), 1f)
        }, LinearLayout.LayoutParams(-1, -2))
    }

    private fun addButton(label: String, action: () -> Unit) {
        val button = Button(this).apply {
            text = label
            isAllCaps = false
            textSize = 14f
            setTextColor(Color.WHITE)
            background = rounded(0xFF202B3A.toInt(), 16)
            setOnClickListener { action() }
        }
        val lp = LinearLayout.LayoutParams(-1, dp(54))
        lp.setMargins(0, dp(4), 0, dp(4))
        root.addView(button, lp)
    }

    private fun addSpace(value: Int) {
        root.addView(View(this), LinearLayout.LayoutParams(1, dp(value)))
    }

    private fun rounded(color: Int, radius: Int) = GradientDrawable().apply {
        setColor(color)
        cornerRadius = dp(radius).toFloat()
    }

    private fun dp(value: Int) = (value * resources.displayMetrics.density).toInt()
    private fun toast(message: String) = Toast.makeText(this, message, Toast.LENGTH_LONG).show()
}
