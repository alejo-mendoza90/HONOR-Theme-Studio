# HONOR Theme Studio

Aplicación Android nativa en Kotlin, diseñada inicialmente para HONOR Magic6 Lite y Android 15/MagicOS.

## Funciones implementadas
- Interfaz oscura premium.
- Vista previa visual de pantalla de bloqueo/inicio (maqueta dentro de la app).
- Selector de imagen y aplicación como fondo de pantalla.
- Generador de fondo degradado usando el color de acento.
- Cinco colores de acento guardados localmente.
- Accesos a ajustes de pantalla, sonido y seguridad.

## Importar y compilar
1. Instala Android Studio (versión compatible con Android Gradle Plugin 8.7.3).
2. Abre la carpeta `HonorThemeStudio`.
3. Permite que Gradle sincronice y descargue el Android Gradle Plugin.
4. Conecta el HONOR Magic6 Lite con depuración USB o usa un emulador.
5. Pulsa Run para instalar.

Para generar un APK: **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Límites reales
Android no permite a una aplicación ordinaria cambiar globalmente los iconos de otras apps, recursos de MagicOS, barra de estado, panel rápido, fuentes del sistema o pantalla de bloqueo propietaria. Para ello se requiere soporte de HONOR Themes, un launcher compatible, permisos privilegiados o root. Este proyecto no usa root. La vista previa no modifica esos elementos; representa cómo se vería una propuesta de tema.

## Próximas ampliaciones
- Exportador de paquetes de recursos para flujos compatibles con HONOR Themes (requiere validar formato por versión/región).
- Editor de iconos PNG y paquetes para launchers.
- Fondos animados mediante servicio de Live Wallpaper.
- Catálogo local de temas y editor de tipografías dentro de la app.
